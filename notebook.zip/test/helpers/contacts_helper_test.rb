require 'test_helper'

class ContactsHelperTest < ActionView::TestCase
end
