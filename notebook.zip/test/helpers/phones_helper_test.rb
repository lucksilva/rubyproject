require 'test_helper'

class PhonesHelperTest < ActionView::TestCase
end
