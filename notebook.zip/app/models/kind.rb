class Kind < ActiveRecord::Base
  has_many :contacts
end
