module HomeHelper
  
  def mostrar_meu_nome
    "Lucas Correia da Silva"
  end
end
